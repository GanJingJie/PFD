# PFD_ATM3.0_ScamAlert

## Things to focus on currently
2FA (Focus)<br/>
3D Face recognition <br/>
Signature

## Complete by week 4
### Wireframe updates:
UI and Design
### OTP
### Database

